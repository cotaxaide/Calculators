			TSO Login Helper
			  Version 3.00

This application was created as an aid for counselors because:

 - TaxSlayer (TSO) has different URLs for production and for training
 - Counselors may not easily remember their login parameters
 - Counselors may be working at several sites during the season
 - Laptops may be used by several counselors
 - Counselors may wish to have additional browser tabs open to other resources

To install:

   1. Open the zip file and copy or move the executable from the zip file to
      any folder you wish - dragging directly to the desktop is the simplest since
      you don't have to worry about adding a shortcut.

Run the application and read the help tab for further information and instructions.

Two local files are created in your Documents folder:
   1. TSO.ini, contains your configuration information
   2. TSO_Help.html, the help file

To remove the application, just delete all three files.

The application was created by Jeff Bogart (CO1D18 TC/ERO, jeff@bogarthome.net)
using AutoIt version 3.3.12.0 to meet situations in that District.
Suggestions for improvement are always welcome.
